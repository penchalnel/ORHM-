package WebTableFormat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dynamic_WebTable {

	
	public static void main(String[] args) throws Exception {
//		Workbook workbook = null;
//		File file =    new File("C:\\Users\\new\\eclipse-workspace\\BrowserAutomation\\src\\com\\ExcelFiles\\Single Testdata.xlsx");
//		FileInputStream file1=new FileInputStream(file); 
//		
//		workbook = new XSSFWorkbook(file1);
//		Sheet sheet=workbook.getSheet("Sheet2");
//		FileOutputStream file2=null;
//		file1.close();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\new\\eclipse-workspace\\BrowserAutomation\\DriverFiles\\chromedriver.exe");
		WebDriver driver = null;
		driver=new ChromeDriver();
		String url="https://www.timeanddate.com/worldclock/";	
		driver.get(url);
		driver.manage().window().maximize();
		///html/body/div[1]/div[6]/section[1]/div/section/div[1]/div/table
		WebElement table=driver.findElement(By.xpath("/html/body/div[1]/div[6]/section[1]/div/section/div[1]/div/table"));
                List<WebElement>rows=table.findElements(By.tagName("tr"));
                for(int i=0;i<rows.size();i++) {
                List<WebElement>Cols=rows.get(i).findElements(By.tagName("td"));
                for(int k=0;k<Cols.size();k++) {
                	String data= Cols.get(k).getText();
//                	file2=new FileOutputStream("C:\\Users\\new\\eclipse-workspace\\BrowserAutomation\\src\\com\\ExcelFiles\\Single Testdata.xlsx"); 
//                	
//                	sheet.getRow(i).createCell(k).setCellValue(data);
//
//                    workbook.write(file2);  
                	
                	System.out.print(data+" ");
                }
                System.out.println();
                      
                }            
           
	}

}
